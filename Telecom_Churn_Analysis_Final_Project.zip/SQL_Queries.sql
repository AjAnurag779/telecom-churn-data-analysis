SELECT Churn, COUNT(*) FROM telecom GROUP BY Churn;
SELECT AVG(MonthlyCharges) FROM telecom WHERE Churn = 1;