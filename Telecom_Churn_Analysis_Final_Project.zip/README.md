# Customer Churn Analysis for Telecom Industry
End-to-end data analytics & ML project using Python, SQL, and Dashboard.